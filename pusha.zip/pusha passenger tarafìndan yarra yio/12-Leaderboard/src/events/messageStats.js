const client = global.client;
const { MessageEmbed } = require("discord.js");
const config = require("../configs/config.json");
const messageUser = require("../schemas/messageUser");
const messageGuild = require("../schemas/messageGuild");
const guildChannel = require("../schemas/messageGuildChannel");
const messageUserChannel = require("../schemas/messageUserChannel");
const nums = new Map();

/**
 * @param { Message } message 
 * @returns 
 */
 module.exports = async (message) => {

    const messageData = await messageUser.findOne({ guildID: message.guild.id, userID: message.author.id });
    const logKanal = message.guild.channels.cache.get(config.badges.prizeLog);

    if (message.guild.roles.cache.get(config.badges.cbronze) && config.staffRoles.some((e) => message.member.roles.cache.get(e)) && messageData && logKanal && !message.member.roles.cache.get(config.badges.cbronze) && ((messageData ? messageData.topStat : 0) > config.targetAmount.cbronze) && ((messageData ? messageData.topStat : 0) < config.targetAmount.csilver)) {
        logKanal.send(`${message.member.toString()}, \`${parseInt(config.targetAmount.cbronze).toLocaleString()} adet mesaj\` hedefine ulaştığı için \`${message.guild.roles.cache.get(config.badges.cbronze).name}\` rolünü kazandı!`);
        await message.member.roles.add(config.badges.cbronze, `Mesaj Hedef Ödülü | ${message.guild.roles.cache.get(config.badges.cbronze).name}`);
    } else if (message.guild.roles.cache.get(config.badges.csilver) && config.staffRoles.some((e) => message.member.roles.cache.get(e)) && messageData && logKanal && !message.member.roles.cache.get(config.badges.csilver) && ((messageData ? messageData.topStat : 0) > config.targetAmount.csilver) && ((messageData ? messageData.topStat : 0) < config.targetAmount.cgold)) {
        logKanal.send(`${message.member.toString()}, \`${parseInt(config.targetAmount.csilver).toLocaleString()} adet mesaj\` hedefine ulaştığı için \`${message.guild.roles.cache.get(config.badges.csilver).name}\` rolünü kazandı!`);
        await message.member.roles.add(config.badges.csilver, `Mesaj Hedef Ödülü | ${message.guild.roles.cache.get(config.badges.csilver).name}`);
        await message.member.roles.remove(config.badges.cbronze, `Eski Mesaj Hedef Ödülü | ${message.guild.roles.cache.get(config.badges.cbronze).name}`);
    } else if (message.guild.roles.cache.get(config.badges.cgold) && config.staffRoles.some((e) => message.member.roles.cache.get(e)) && messageData && logKanal && !message.member.roles.cache.get(config.badges.cgold) && ((messageData ? messageData.topStat : 0) > config.targetAmount.cgold) && ((messageData ? messageData.topStat : 0) < config.targetAmount.cdia)) {
        logKanal.send(`${message.member.toString()}, \`${parseInt(config.targetAmount.cgold).toLocaleString()} adet mesaj\` hedefine ulaştığı için \`${message.guild.roles.cache.get(config.badges.cgold).name}\` rolünü kazandı!`);
        await message.member.roles.add(config.badges.cgold, `Mesaj Hedef Ödülü | ${message.guild.roles.cache.get(config.badges.cgold).name}`);
        await message.member.roles.remove(config.badges.csilver, `Eski Mesaj Hedef Ödülü | ${message.guild.roles.cache.get(config.badges.csilver).name}`);
    } else if (message.guild.roles.cache.get(config.badges.cdia) && config.staffRoles.some((e) => message.member.roles.cache.get(e)) && messageData && logKanal && !message.member.roles.cache.get(config.badges.cdia) && ((messageData ? messageData.topStat : 0) > config.targetAmount.cdia) && ((messageData ? messageData.topStat : 0) < config.targetAmount.cemerl)) {
        logKanal.send(`${message.member.toString()}, \`${parseInt(config.targetAmount.cdia).toLocaleString()} adet mesaj\` hedefine ulaştığı için \`${message.guild.roles.cache.get(config.badges.cdia).name}\` rolünü kazandı!`);
        await message.member.roles.add(config.badges.cdia, `Mesaj Hedef Ödülü | ${message.guild.roles.cache.get(config.badges.cdia).name}`);
        await message.member.roles.remove(config.badges.cgold, `Eski Mesaj Hedef Ödülü | ${message.guild.roles.cache.get(config.badges.cgold).name}`);
    } else if (message.guild.roles.cache.get(config.badges.cemerl) && config.staffRoles.some((e) => message.member.roles.cache.get(e)) && messageData && logKanal && !message.member.roles.cache.get(config.badges.cemerl) && ((messageData ? messageData.topStat : 0) > config.targetAmount.cemerl)) {
        logKanal.send(`${message.member.toString()}, \`${parseInt(config.targetAmount.cemerl).toLocaleString()} adet mesaj\` hedefine ulaştığı için \`${message.guild.roles.cache.get(config.badges.cemerl).name}\` rolünü kazandı!`);
        await message.member.roles.add(config.badges.cemerl, `Mesaj Hedef Ödülü | ${message.guild.roles.cache.get(config.badges.cemerl).name}`);
        await message.member.roles.remove(config.badges.cdia, `Eski Mesaj Hedef Ödülü | ${message.guild.roles.cache.get(config.badges.cdia).name}`);
    }

    const prefix = config.prefix.find((e) => message.content.toLowerCase().startsWith(e));
    if (message.author.bot || !message.guild || prefix) return;



    await messageUser.findOneAndUpdate({ guildID: message.guild.id, userID: message.author.id }, { $set: { timeout: Date.now() }, $inc: { topStat: 1, dailyStat: 1, weeklyStat: 1, twoWeeklyStat: 1 } }, { upsert: true });
    await messageGuild.findOneAndUpdate({ guildID: message.guild.id }, { $inc: { topStat: 1, dailyStat: 1, weeklyStat: 1, twoWeeklyStat: 1 } }, { upsert: true });
    await guildChannel.findOneAndUpdate({ guildID: message.guild.id, channelID: message.channel.id }, { $inc: { channelData: 1 } }, { upsert: true });
    await messageUserChannel.findOneAndUpdate({ guildID: message.guild.id, userID: message.author.id, channelID: message.channel.id }, { $inc: { channelData: 1 } }, { upsert: true });
};

module.exports.conf = {
    name: "message"
};
