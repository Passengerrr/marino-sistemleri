# Bilgilendirme Önemli Okuyun İste
- Bana Hazır Alt Yapici Diyenlere Sesleniyorum Canım Arkadaslarım Madem Hazır Alt Yapiciyim Ben Zaten Diyorum Bunu Ama Sizin Alt Yapilarinizla Alakası Yok Bu Alt Yapilarin Niye Bana Bunu Acıklayın Aga Hayır Theark Yaptigi Botu Jaylen Editleyip Gelistirdi Bende Ondan Aldım Daha Cok Sey Ekledım Guardlar Zaten Kendim Yaptim Demiyorum Gelistirdim Diyorum Ve Alt Yapilarinizdan Daha Sağlam Kısaca Gidin Kendinizle Dalga Geçin Gidin Bulun Alt Yapilari Bukadar Basıt Cok Biliyorsunuz Ya Ego Yapiyonuz Ya İste Buyuzden Hic Bir SERVER Bot Yapmadım Ben Bugune Kadar Okadar Teklif Geldi Red Etim Bana Gelip Boş Edabeyat Yapmayın Genclik Ben Kendime Çalısırım Sadece Simdide Milete Calısacam Oda Yardım Amaçlı Sizin Gibi Ego Yapmıcam Kısaca 

# Bilgilendirme 

- Butun Botların Fiyati Söyliyorum Hemen v12 Butun Botlarım 150 TL V13 Butun Botlarım 200 TL 
- Botları Sen Yap Derseniz Aylık 100Tl Vds Parası Ve V12 İstiyorsanız 90TL Bot Ücreti V13 İstiyorsanız 120TL Bot Ücreti

- Benle İletisime Gecmek İsteyen Arkadaslarsa instagram : pusha__23 Discord Adresimse ✰ ' Pusha#0268 Ve Discord Sunucumda discord.gg/marino Beni Boyle Bula Bilirsiniz Neyse Hepinize İyi Günler Seviliyorsunuz

# Pusha Guard Bots

- Sekme Guard Buttonlu Ve Hersey Vardir
- Guard Kanal/Katagori/Rol/Emoji/Webhook/Url/Sagtık İsim Değisme/Sag Tık Kick/Sag Tık Ban/Ve Sunucu İlgili Bir Cok Sey Vardır/
- Backup Otomatik Rol Silinçe Kendisi Olusturur Ve Otomatik Dağitir Kanal İzinlerini Ayarlar Ve Rol Kim Varsa Herkeşe Vermektedir
- Chat Guard Küfür/Caps/Chat Limit/Etiket/ Gibi Daha Bir Çok Chate İlgili Korumalarımız Bulunmaktadır

# Pusha Destek Bots

- Destek Bots Olan Özelikler Yetkili Alim / Buttonlu Destek Ve Log Özeligi Bulunmaktadir

# Pusha Logger Bots

- Logger Bots Logger Dedimiz Bot Herseyi Loglayan Bota Denir Rol Silinince Log Kanalına Mesaj Atar Ban Yiyince Birisi Ve Bir Çok Özeligide Vardir

# Pusha Welcome Bots

- Welcome bots Hem Mongolu Hemde Komutludur Zaten Ekran Fotoraflarında Görürsünüz Komutlarda İstediginiz Gibi Ses Kayıdına Gecer

# Pusha Main Bots

 Not: 5 tasarım yaptım random seçip veri kartı oluşturuyor...

![image](https://user-images.githubusercontent.com/92666466/152353271-47cc6c6e-d838-478e-9c64-5d0584765351.png)

- Testleri yapılmıştır. Hiçbir hatası bulunmamaktadır starlarınızı bekliyorum yeni github hesabım.
- Sizlerle geliştirmiş olduğum botlardan biriyle tanıştırmak istiyorum.. 
- Invite, Moderasyon, Butonlu Register /Oto Register, Stats, Buton sistemleri.

# Yapmanız gereken adımlar

Not: Aşağıdaki hata için veya welcome mesaj sorunu için .ytag ekle sil yapmanız gerekmektedir.

![image](https://user-images.githubusercontent.com/92666466/150496311-fa4725af-1d36-4004-b457-bcacfaee238b.png)

Not: Aşağıdaki Gördünüz Yaş Ayaridir Eyerki 14 Yaş Altisa Kayit Edilmez 14 Ve Üştuse Kayit Eder Dilediginiz Gibide Ayarlaya Bilirsiniz

![image](https://cdn.discordapp.com/attachments/932215403646681101/934076446790529065/unknown.png)


Not: Aşağada Gördünüz Kod .e ve .k Kodudur Taglı Alim orda Gördiniz İki Rol İdsine Booster Ve Vip İdsi Girilcektir

```js
const tagModedata = await regstats.findOne({ guildID: message.guild.id })
    if (tagModedata && tagModedata.tagMode === true) {
    if(!uye.user.username.includes(ayar.tag) && !uye.roles.cache.has("923331950905794568") &&  !uye.roles.cache.has("923536502875623455")) 
```

Not: menuselcut 360 satırdaki
```js
if (!menu.clicker.member.roles.cache.get("family rol id") && !menu.clicker.member.roles.cache.get("booster rol id")) return await menu.reply.edit("Booster & Taglu üye olman gerek!"); 
```

Not: Aşağıdaki rol menü sisteminde sol kısımdakiler emoji id isterseniz öyle kalabilir o kısım beğenmezseniz değişirsiniz, sağ kısımlarındaki ise rol idleridir. Sırasıyla .menü <katılım/burc/oyun/renk/iliski/etkin> komutları kullanılırsa alttaki ss düzeninde olucaktır menü sistemi

```js
const katılımcı = {
  "941075067230625803": "Etkinlik_Rol_İd",
  "941074179401338900": "Çekiliş_Rol_İd"
}; 

const etkinlik = {
  "941885170183708682": "dc",
  "941885176609374219": "vk"
}; 

const burclar = {
  "931658642955075604": "Yengeç_Rol_İd",
  "931657544756248606": "Aslan_Rol_İd",
  "931658863923593297": "Akrep_Rol_İd",
  "931658464512598056": "Oğlak_Rol_İd",
  "931657587886264340": "Balık_Rol_İd",
  "931658178482012201": "Başak_Rol_İd",
  "931658397860892672": "Kova_Rol_İd",
  "931658529314603008": "Terazi_Rol_İd",
  "931658575951048714": "Yay_Rol_İd",
  "931658251181887508": "Koç_Rol_İd",
  "931658687028789289": "İkizler_Rol_İd",
  "931659095629529168": "Boğa_Rol_İd"
};

const renkler = {
  "746992558927904891": "Kırmızı_Rol_İd",
  "746992700099657830": "Turuncu_Rol_İd",
  "746992666926907393": "Mavi_Rol_İd",
  "746992603186069615": "Pembe_Rol_İd",
  "746992734434230383": "Yeşil_Rol_İd"
};

const ilişki = {
  "855054137296814101": "Sevgilim_Var_Rol_İd",
  "835704673204830238": "Sevgilim_Yok_Rol_İd",
  "941885145999368212": "lgbt",
  "941885143239524432": "I want Lover",
  "941885146792071209": "I do not need anyone"
}; 

const oyunlar = {
  "880606175274598461":"CS:GO_Rol_İd",
  "880606175761145906":"League_of_Legends_Rol_İd",
  "880606175387873281":"Valorant_Rol_İd",
  "880606175408824321":"GTA_V_Rol_İd",
  "880606175178153994":"Pubg_Rol_İd",
  "880606175488540693":"Fortnite_Rol_İd",
  "843187231539855370":"minecraft",
  "932614645892669511":"amangous"
};

```

# Rol Alma Sistemi
![image](https://cdn.discordapp.com/attachments/932377086205788290/944153907855253604/unknown.png)
![image](https://cdn.discordapp.com/attachments/932377086205788290/932378439338561606/unknown.png)
![image](https://cdn.discordapp.com/attachments/932377086205788290/932378511161835530/unknown.png)

# Market Ve Coin Sistemi
![image](https://cdn.discordapp.com/attachments/932377086205788290/944154222008598598/unknown.png)
![image](https://cdn.discordapp.com/attachments/932377086205788290/944154060708261928/unknown.png)

# Owner Sistemi
![image](https://cdn.discordapp.com/attachments/932377086205788290/932377096884461618/unknown.png)
![image](https://cdn.discordapp.com/attachments/945760987376648259/948931011943743560/unknown.png)

# Kayıt Sistemi
![image](https://cdn.discordapp.com/attachments/932377086205788290/932377204032159775/unknown.png)
![image](https://cdn.discordapp.com/attachments/932377086205788290/932377418696638615/unknown.png)

# Terfi Sistemi
![image](https://cdn.discordapp.com/attachments/932377086205788290/932377740940836895/unknown.png)
![image](https://cdn.discordapp.com/attachments/932377086205788290/932377844305264680/unknown.png)
![image](https://cdn.discordapp.com/attachments/932377086205788290/932378283704733746/unknown.png)

# Ceza Sistemi
![image](https://cdn.discordapp.com/attachments/932377086205788290/932378376822472704/unknown.png)

# Owo Sistemi
![image](https://cdn.discordapp.com/attachments/932377086205788290/932380060466413708/unknown.png)
![image](https://cdn.discordapp.com/attachments/932377086205788290/932380333821804564/unknown.png)

# Kullanıcı Paneli
![image](https://cdn.discordapp.com/attachments/932377086205788290/932378589184278569/unknown.png)

# Leaderboard
![image](https://cdn.discordapp.com/attachments/945760991805866014/948929796497375253/unknown.png)
![image](https://media.discordapp.net/attachments/945754309474271272/946380019448557578/unknown.png?width=631&height=473)

# WELCOME 
![image](https://cdn.discordapp.com/attachments/945760991805866014/949477324905152542/unknown.png)
![image](https://cdn.discordapp.com/attachments/945760991805866014/949477447538204792/unknown.png)

# SEKME GUARD
![image](https://cdn.discordapp.com/attachments/936186092040880188/936186097996791818/unknown.png)
![image](https://cdn.discordapp.com/attachments/936186092040880188/936186686201823262/unknown.png)
